class Data {
    name = null;
    id = null;
    head = null;
    score = null;
}

export default new Data();

