"use strict";
module.exports = {
    description: "重新生成uuid并自动关联",
    developer: "开发者",
    label: "重新生成UUID",
    selecttitle: "请选择要刷新uuid资源的根目录",
    yourSelect: "所选目录",
    warningMsg: "是否重新生成所选目录下所有文件的uuid?\n点击确定前请备份好资源，所选根目录外引用根目录内的资源会丢失!!!",
    warningTitle: "警告",
    warningBtnSure: "确定",
    warningBtnCancel: "取消"
};